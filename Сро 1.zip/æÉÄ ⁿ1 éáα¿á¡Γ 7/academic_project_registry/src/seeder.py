from datetime import datetime
from database import get_db

def seed_synthetic_data():
    """Генерация 30+ синтетических документов проектов (Требование 2)."""
    db = get_db()
    collection = db["projects"]
    
    # Очищаем коллекцию перед генерацией
    collection.drop()
    
    projects_batch = []
    
    # Цикл для генерации ровно 30 уникальных документов
    for i in range(1, 31):
        # Циклическое распределение статусов
        if i % 3 == 0:
            status = "Completed"
        elif i % 3 == 1:
            status = "Active"
        else:
            status = "In Review"
            
        project = {
            "title": f"Учебный проект №{i}: Разработка NoSQL подсистемы",
            "description": f"Автоматизированный модуль регистрации данных кафедры. Версия {i}.0",
            "department": "Информационные Системы",
            "leader_id": f"STU_100{i}",
            "status": status,
            "tags": ["NoSQL", "Университет", "Backend" if i % 2 == 0 else "Frontend"],
            "technologies": ["MongoDB", "Python", "Docker"] if i % 2 == 0 else ["React", "Node.js", "Express"],
            "created_at": datetime(2026, 9, 1),
            "deadline": datetime(2026, 12, 25),
            "members": [
                {"student_id": f"STU_100{i}", "role": "Team Lead", "name": f"Студент Лидер {i}"},
                {"student_id": f"STU_200{i}", "role": "Developer", "name": f"Студент Разработчик {i}"}
            ],
            "tasks": [
                {
                    "task_id": f"TSK_{i}01",
                    "title": "Проектирование схемы денормализованных данных",
                    "assignee_id": f"STU_100{i}",
                    "status": "Done" if status == "Completed" else "In Progress",
                    "priority": "High"
                },
                {
                    "task_id": f"TSK_{i}02",
                    "title": "Разработка интеграционных сценариев",
                    "assignee_id": f"STU_200{i}",
                    "status": "To Do",
                    "priority": "Medium"
                }
            ]
        }
        projects_batch.append(project)
        
    collection.insert_many(projects_batch)
    print(f"[УСПЕХ] В коллекцию загружено {len(projects_batch)} синтетических проектов.")