from database import get_db, init_indexes
from seeder import seed_synthetic_data

def run_all_queries():
    db = get_db()
    col = db["projects"]
    
    print("\n================== ВЫПОЛНЕНИЕ 8 ДЕМОНСТРАЦИОННЫХ ЗАПРОСОВ ==================\n")
    
    # --- CRUD: CREATE ---
    print("Запрос 1 [CREATE]: Добавление нового проекта:")
    new_project = {
        "title": "Учебный проект №31: Новая инициатива",
        "status": "Active",
        "leader_id": "STU_9999",
        "tags": ["Инновации"],
        "tasks": []
    }
    insert_res = col.insert_one(new_project)
    print(f"-> Успешно добавлен документ с ID: {insert_res.inserted_id}\n")
    
    # --- CRUD: READ ---
    print("Запрос 2 [READ]: Поиск проекта по точному названию:")
    p2 = col.find_one({"title": "Учебный проект №7: Разработка NoSQL подсистемы"})
    print(f"-> Найден проект. Статус: {p2['status']} | Лидер: {p2['leader_id']}\n")
    
    print("Запрос 3 [READ]: Выборка активных проектов с технологией 'MongoDB':")
    for p3 in col.find({"status": "Active", "technologies": "MongoDB"}).limit(2):
        print(f"-> [Активен] {p3['title']}")
    print()
    
    print("Запрос 4 [READ]: Поиск задач исполнителя 'STU_2005' внутри массивов:")
    for p4 in col.find({"tasks.assignee_id": "STU_2005"}):
        for task in p4["tasks"]:
            if task["assignee_id"] == "STU_2005":
                print(f"-> Проект: {p4['title']} | Задача: {task['title']} [{task['status']}]")
    print()
    
    # --- CRUD: UPDATE ---
    print("Запрос 5 [UPDATE]: Изменение статуса и добавление тега:")
    upd_res = col.update_one(
        {"title": "Учебный проект №7: Разработка NoSQL подсистемы"},
        {"$set": {"status": "In Review"}, "$addToSet": {"tags": "Ozen"}}
    )
    print(f"-> Документов модифицировано: {upd_res.modified_count}\n")
    
    print("Запрос 6 [UPDATE]: Встраивание (Embedding) новой задачи в проект:")
    task_res = col.update_one(
        {"title": "Учебный проект №7: Разработка NoSQL подсистемы"},
        {"$push": {"tasks": {
            "task_id": "TSK_703",
            "title": "Сборка документации проекта в PDF",
            "assignee_id": "STU_1007",
            "status": "To Do",
            "priority": "High"
        }}}
    )
    print(f"-> Задача встроена. Модифицировано документов: {task_res.modified_count}\n")
    
    # --- НЕТРИВИАЛЬНЫЕ ЗАПРОСЫ (АГРЕГАЦИЯ) ---
    print("Запрос 7 [AGREGATION - НЕТРИВИАЛЬНЫЙ 1]: Подсчет задач по приоритетам:")
    pipeline_1 = [
        {"$unwind": "$tasks"},
        {"$group": {"_id": "$tasks.priority", "count": {"$sum": 1}}},
        {"$sort": {"count": -1}}
    ]
    for agg1 in col.aggregate(pipeline_1):
        print(f"-> Приоритет '{agg1['_id']}': {agg1['count']} шт.")
    print()
    
    print("Запрос 8 [AGREGATION - НЕТРИВИАЛЬНЫЙ 2]: Топ-3 лидера по числу активных проектов:")
    pipeline_2 = [
        {"$match": {"status": "Active"}},
        {"$group": {"_id": "$leader_id", "active_count": {"$sum": 1}}},
        {"$sort": {"active_count": -1}},
        {"$limit": 3}
    ]
    for agg2 in col.aggregate(pipeline_2):
        print(f"-> Студент {agg2['_id']} ведет активных проектов: {agg2['active_count']}")
    print()
    
    # --- CRUD: DELETE ---
    print("Запрос 9 [DELETE]: Удаление созданного тестового проекта №31:")
    del_res = col.delete_one({"title": "Учебный проект №31: Новая инициатива"})
    print(f"-> Удалено документов: {del_res.deleted_count}\n")

if __name__ == "__main__":
    # Полный цикл запуска для демонстрации преподавателю
    init_indexes()
    seed_synthetic_data()
    run_all_queries()