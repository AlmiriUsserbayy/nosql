import os
from pymongo import MongoClient, ASCENDING, TEXT
from dotenv import load_dotenv

load_dotenv()
MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017/")
DB_NAME = os.getenv("DB_NAME", "academic_registry")

def get_db():
    """Подключение к MongoDB и возврат объекта базы данных."""
    client = MongoClient(MONGO_URI)
    return client[DB_NAME]

def init_indexes():
    """Создание индексов для оптимизации Access Patterns (Требование 2)."""
    db = get_db()
    collection = db["projects"]
    
    # Очищаем старые индексы перед пересозданием
    collection.drop_indexes()
    
    # 1. Индекс для быстрого поиска по исполнителю внутри массива задач (Embedded)
    collection.create_index("tasks.assignee_id")
    
    # 2. Текстовый индекс для поиска по ключевым технологиям и тегам
    collection.create_index([("tags", TEXT), ("technologies", TEXT)])
    
    # 3. Составной индекс для фильтрации по статусу проекта и дедлайну
    collection.create_index([("status", ASCENDING), ("deadline", ASCENDING)])
    
    print("[УСПЕХ] Индексы MongoDB успешно инициализированы.")